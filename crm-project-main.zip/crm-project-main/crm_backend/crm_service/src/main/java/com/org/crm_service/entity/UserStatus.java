package com.org.crm_service.entity;

public enum UserStatus {
    PENDING,
    ACTIVE,
    INACTIVE,
    REJECTED
}
