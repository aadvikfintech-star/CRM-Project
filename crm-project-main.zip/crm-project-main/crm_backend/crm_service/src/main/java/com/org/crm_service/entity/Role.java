package com.org.crm_service.entity;

public enum Role {
    ADMIN,
    USER
}
